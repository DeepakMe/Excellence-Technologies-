from django.contrib import admin
from accounts.models import UserAddress
# Register your models here.


class UserAddressAdmin(admin.ModelAdmin):
    list_display = ['username', 'user_street', 'user_pincode', 'user_country', 'user_state', 'user_contact']


admin.site.register(UserAddress, UserAddressAdmin)
