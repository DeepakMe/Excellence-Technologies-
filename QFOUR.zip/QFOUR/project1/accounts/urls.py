from django.urls import path, include
from accounts import views

urlpatterns = [
    path('login/', views.login , name="login"),
    path('register/', views.register, name="register"),
    path('add/', views.add_address , name="add"),
    path('update/', views.update_address, name="update"),
    
]
