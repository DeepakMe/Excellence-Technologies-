from django.db import models
from django.contrib.auth.models import User
# Create your models here.

    
class UserAddress(models.Model):
    username = models.ForeignKey(User, on_delete=models.CASCADE)
    user_street = models.CharField(max_length=256)
    user_pincode = models.CharField(max_length=6)
    user_country = models.CharField(max_length=256)
    user_state = models.CharField(max_length=256)
    user_contact = models.CharField(max_length=10, primary_key=True)




